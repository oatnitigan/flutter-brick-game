//import 'package:flame/game.dart';
import 'package:flutter/material.dart';
//import 'src/brick_breaker.dart';
import 'src/widgets/game_app.dart';

void main() {
  runApp(const GameApp());
}
